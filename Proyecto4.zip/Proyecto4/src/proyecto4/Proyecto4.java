/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package proyecto4;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author AT
 */
public class Proyecto4 {
        public Connection conexion;
    private String url, user, pass;
    private Statement state;
    private ResultSet respuesta;
    

     public Proyecto4(){
        url = "jdbc:mysql://localhost:3306/db_programacion_parcial4?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        user = "root";
        pass= "";
        
        try {
            conexion =DriverManager.getConnection(url,user,pass);
            System.out.println("Conexion exitosa");
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Proyecto4 pru = new Proyecto4();
    }
        public ResultSet cargar(){
        try {
            state = conexion.createStatement();
            respuesta = state.executeQuery("SELECT p.*, D.descripcionCargo, T.descripcionTipo FROM empleado AS p INNER JOIN cargo AS D ON p.idCargo = D.idCargo INNER JOIN tipousuario AS T ON p.idTipoUsuario = T.idTipo");
            return respuesta;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public void cerrarConexion(){
        try {
            conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public boolean insertar(empleado p){
        try {
            String sqlConsulta = "INSERT INTO empleado VALUES(null,'"+p.nombre+"','"+p.dui+"',"+p.salario+","+p.idCargo+","+p.idTipoUsuario+")";
            state = conexion.createStatement();
            state.executeUpdate(sqlConsulta);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
             return false;
        }
    }
    public boolean editar(empleado p){
            try {
            String sqlConsulta = "UPDATE empleado SET nombre='"+p.nombre+"',dui='"+p.dui+"',salario="+p.salario+",idCargo="+p.idCargo+",idTipoUsuario="+p.idTipoUsuario+" WHERE idEmpleado="+p.idEmpleado+"";
            state = conexion.createStatement();
            state.executeUpdate(sqlConsulta);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
             return false;
        }
    }
    
    public boolean eliminar(int id){
            try {
            String sqlConsulta = "DELETE FROM empleado WHERE id_persona="+id;
            state = conexion.createStatement();
            state.executeUpdate(sqlConsulta);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
             return false;
        }
    }
    
    public ResultSet CargarCargo(){
        try {
            state = conexion.createStatement();
            respuesta = state.executeQuery("SELECT * FROM cargo");
            return respuesta;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ResultSet cargarTipoUsuario(){
        try {
            state = conexion.createStatement();
            respuesta = state.executeQuery("SELECT * FROM tipousuario");
            return respuesta;
        } catch (SQLException ex) {
            Logger.getLogger(Proyecto4.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    
}
